import importlib
from pathlib import Path
from types import SimpleNamespace

import pytest

from backend.utils.translate_utils import is_translation_request, should_translate, translation_targets_requested


def test_is_translation_request_false_for_original_source_auto():
    assert not is_translation_request("Original", "Auto")
    assert not is_translation_request("Source", "Auto")
    assert not is_translation_request("Auto", "Auto")


def test_is_translation_request_false_for_same_language():
    assert not is_translation_request("English", "English")
    assert not is_translation_request("english", "English")


def test_should_translate_only_with_enabled_provider_and_translate_language():
    assert should_translate("English", "Auto", True)
    assert not should_translate("English", "Auto", False)
    assert not should_translate("Original", "Auto", True)


def test_translation_targets_requested_checks_each_language():
    assert not translation_targets_requested(["Original"], "Auto")
    assert translation_targets_requested(["Traditional Chinese"], "Auto")
    assert translation_targets_requested(["Original", "Traditional Chinese"], "Auto")


def test_finalize_pipeline_skips_translate_segments_for_original_language(monkeypatch, tmp_path):
    import backend.tasks as tasks
    import backend.utils.translate_utils as translate_utils

    monkeypatch.setenv("UPLOAD_DIR", str(tmp_path / "uploads"))
    monkeypatch.setattr(tasks.settings, "OPENAI_API_KEY", "")
    monkeypatch.setattr(tasks.settings, "TESTING", False)

    translate_called = {"called": False}

    def fake_translate_segments(*args, **kwargs):
        translate_called["called"] = True
        raise AssertionError("translate_segments should not be called for Original target language")

    import backend.utils.split_utils as split_utils

    monkeypatch.setattr(translate_utils, "translate_segments", fake_translate_segments)
    monkeypatch.setattr(tasks, "prepare_segment_results_for_merge", lambda results: results)
    monkeypatch.setattr(split_utils, "merge_segments_subtitles", lambda results: results)

    def fake_generate_bilingual_srt(segments, translated_texts, output_path):
        Path(output_path).write_text("ok")
        return output_path

    monkeypatch.setattr(translate_utils, "generate_bilingual_srt", fake_generate_bilingual_srt)

    class DummyStorage:
        def upload_file(self, *args, **kwargs):
            return None

    monkeypatch.setattr(tasks, "get_storage_backend", lambda: DummyStorage())

    video_path = tmp_path / "input.mp4"
    video_path.write_bytes(b"dummy content")

    result = tasks.finalize_pipeline(
        [SimpleNamespace(text="hello", start=0.0, end=1.0)],
        str(video_path),
        {
            "business_id": "task1",
            "target_langs": ["Original"],
            "subtitle_format": "srt",
            "burn_subtitles": False,
        },
    )

    assert result["translations"][0]["translated"] is False
    assert translate_called["called"] is False
    output = (tmp_path / "uploads" / "task1_Original.srt").read_text(encoding="utf-8")
    assert "hello\nhello" not in output
    assert output.count("hello") == 1


def test_finalize_pipeline_translated_output_is_bilingual(monkeypatch, tmp_path):
    import backend.tasks as tasks
    import backend.utils.split_utils as split_utils
    import backend.utils.translate_utils as translate_utils

    monkeypatch.setenv("UPLOAD_DIR", str(tmp_path / "uploads"))
    monkeypatch.setattr(tasks, "prepare_segment_results_for_merge", lambda results: results)
    monkeypatch.setattr(split_utils, "merge_segments_subtitles", lambda results: results)
    monkeypatch.setattr(tasks, "ensure_translation_available", lambda _langs: SimpleNamespace(translation_enabled=True))
    monkeypatch.setattr(translate_utils, "translate_segments", lambda *_args, **_kwargs: ({"Japanese": ["konnichiwa"]}, []))

    class DummyStorage:
        def upload_file(self, *args, **kwargs):
            return True

    monkeypatch.setattr(tasks, "get_storage_backend", lambda: DummyStorage())

    video_path = tmp_path / "input.mp4"
    video_path.write_bytes(b"dummy content")

    result = tasks.finalize_pipeline(
        [SimpleNamespace(text="hello", start=0.0, end=1.0)],
        str(video_path),
        {
            "business_id": "task2",
            "target_langs": ["Japanese"],
            "subtitle_format": "srt",
            "burn_subtitles": False,
        },
    )

    output = (tmp_path / "uploads" / "task2_Japanese.srt").read_text(encoding="utf-8")
    assert result["translations"][0]["translated"] is True
    assert "konnichiwa\nhello" in output


def test_finalize_pipeline_translation_fallback_is_monolingual(monkeypatch, tmp_path):
    import backend.tasks as tasks
    import backend.utils.split_utils as split_utils
    import backend.utils.translate_utils as translate_utils

    monkeypatch.setenv("UPLOAD_DIR", str(tmp_path / "uploads"))
    monkeypatch.setattr(tasks, "prepare_segment_results_for_merge", lambda results: results)
    monkeypatch.setattr(split_utils, "merge_segments_subtitles", lambda results: results)
    monkeypatch.setattr(tasks, "ensure_translation_available", lambda _langs: SimpleNamespace(translation_enabled=True))

    def fail_translate(*_args, **_kwargs):
        raise RuntimeError("provider unavailable")

    monkeypatch.setattr(translate_utils, "translate_segments", fail_translate)

    class DummyStorage:
        def upload_file(self, *args, **kwargs):
            return True

    monkeypatch.setattr(tasks, "get_storage_backend", lambda: DummyStorage())

    video_path = tmp_path / "input.mp4"
    video_path.write_bytes(b"dummy content")

    result = tasks.finalize_pipeline(
        [SimpleNamespace(text="hello", start=0.0, end=1.0)],
        str(video_path),
        {
            "business_id": "task3",
            "target_langs": ["Japanese"],
            "subtitle_format": "srt",
            "burn_subtitles": False,
        },
    )

    output = (tmp_path / "uploads" / "task3_Japanese.srt").read_text(encoding="utf-8")
    assert result["translations"][0]["translated"] is False
    assert "hello\nhello" not in output
    assert output.count("hello") == 1


def test_finalize_pipeline_rejects_translation_target_without_openai_key(monkeypatch, tmp_path):
    import backend.tasks as tasks
    import backend.utils.split_utils as split_utils
    import backend.utils.translate_utils as translate_utils

    monkeypatch.setattr(tasks.settings, "LLM_PROVIDER", "openai")
    monkeypatch.setattr(tasks.settings, "OPENAI_API_KEY", "")

    translate_called = {"called": False}

    def fake_translate_segments(*args, **kwargs):
        translate_called["called"] = True
        raise AssertionError("translate_segments should not be called without OPENAI_API_KEY")

    monkeypatch.setattr(translate_utils, "translate_segments", fake_translate_segments)
    monkeypatch.setattr(tasks, "prepare_segment_results_for_merge", lambda results: results)
    monkeypatch.setattr(split_utils, "merge_segments_subtitles", lambda results: results)

    video_path = tmp_path / "input.mp4"
    video_path.write_bytes(b"dummy content")

    with pytest.raises(ValueError, match="OPENAI_API_KEY is required when translation targets are requested"):
        tasks.finalize_pipeline(
            [SimpleNamespace(text="hello", start=0.0, end=1.0)],
            str(video_path),
            {
                "business_id": "task1",
                "target_langs": ["Traditional Chinese"],
                "subtitle_format": "srt",
                "burn_subtitles": False,
            },
        )

    assert translate_called["called"] is False


def test_finalize_pipeline_allows_ollama_without_openai_key(monkeypatch, tmp_path):
    import backend.tasks as tasks
    import backend.utils.split_utils as split_utils
    import backend.utils.translate_utils as translate_utils

    monkeypatch.setattr(tasks.settings, "LLM_PROVIDER", "ollama")
    monkeypatch.setattr(tasks.settings, "OPENAI_API_KEY", "")
    monkeypatch.setattr(tasks.settings, "OLLAMA_MODEL", "gemma3:12b")
    monkeypatch.setattr(tasks, "prepare_segment_results_for_merge", lambda results: results)
    monkeypatch.setattr(split_utils, "merge_segments_subtitles", lambda results: results)
    monkeypatch.setattr(
        tasks,
        "ensure_translation_available",
        lambda _langs: SimpleNamespace(translation_enabled=True),
    )

    def fake_translate_segments(*_args, **_kwargs):
        return {"Traditional Chinese": ["哈囉"]}, []

    def fake_generate_bilingual_srt(_segments, _translated_texts, output_path):
        Path(output_path).write_text("ok", encoding="utf-8")
        return output_path

    monkeypatch.setattr(translate_utils, "translate_segments", fake_translate_segments)
    monkeypatch.setattr(translate_utils, "generate_bilingual_srt", fake_generate_bilingual_srt)

    class DummyStorage:
        def upload_file(self, *args, **kwargs):
            return None

    monkeypatch.setattr(tasks, "get_storage_backend", lambda: DummyStorage())

    video_path = tmp_path / "input.mp4"
    video_path.write_bytes(b"dummy content")

    result = tasks.finalize_pipeline(
        [SimpleNamespace(text="hello", start=0.0, end=1.0)],
        str(video_path),
        {
            "business_id": "task1",
            "target_langs": ["Traditional Chinese"],
            "subtitle_format": "srt",
            "burn_subtitles": False,
        },
    )

    assert result["translations"][0]["translated"] is True


def test_storage_upload_optional_failure_becomes_warning(monkeypatch):
    import backend.tasks as tasks

    class FailingStorage:
        def upload_file(self, *_args, **_kwargs):
            return False

    warnings: list[str] = []
    monkeypatch.setattr(tasks.settings, "STORAGE_BACKEND", "s3")
    monkeypatch.setattr(tasks.settings, "S3_UPLOAD_REQUIRED", False)

    tasks._record_storage_upload(FailingStorage(), "local", "remote", warnings)

    assert warnings == ["Object storage upload failed for remote"]


def test_storage_upload_required_failure_raises(monkeypatch):
    import backend.tasks as tasks

    class FailingStorage:
        def upload_file(self, *_args, **_kwargs):
            return False

    monkeypatch.setattr(tasks.settings, "STORAGE_BACKEND", "s3")
    monkeypatch.setattr(tasks.settings, "S3_UPLOAD_REQUIRED", True)

    with pytest.raises(RuntimeError, match="Object storage upload failed"):
        tasks._record_storage_upload(FailingStorage(), "local", "remote", [])


def test_rebuild_final_uploads_rebuilt_video_to_storage(monkeypatch, tmp_path):
    import backend.tasks as tasks
    import backend.utils.subtitle_video_utils as subtitle_video_utils

    task_id = "77777777-7777-7777-7777-777777777777"
    upload_dir = tmp_path / "uploads"
    upload_dir.mkdir()
    (upload_dir / f"{task_id}.mp4").write_bytes(b"video")
    (upload_dir / f"{task_id}_English.srt").write_text("1\n00:00:00,000 --> 00:00:01,000\nhello\n", encoding="utf-8")

    uploads: list[tuple[str, str]] = []

    class RecordingStorage:
        def upload_file(self, local_path, remote_path):
            uploads.append((local_path, remote_path))
            return True

    def fake_burn(_video_path, _subtitle_path, output_path):
        Path(output_path).write_bytes(b"rebuilt")

    monkeypatch.setenv("UPLOAD_DIR", str(upload_dir))
    monkeypatch.setattr(tasks.settings, "STORAGE_BACKEND", "s3")
    monkeypatch.setattr(tasks.settings, "S3_UPLOAD_REQUIRED", True)
    monkeypatch.setattr(tasks, "get_storage_backend", lambda: RecordingStorage())
    monkeypatch.setattr(subtitle_video_utils, "burn_subtitles", fake_burn)
    monkeypatch.setattr(tasks.rebuild_final_video_task, "update_state", lambda *args, **kwargs: None)

    result = tasks.rebuild_final_video_task.run(task_id, "English", "srt")

    assert result == {"warnings": [], "result_task_id": task_id}
    assert uploads == [(str(upload_dir / f"{task_id}_final.mp4"), f"{task_id}_final.mp4")]


def test_rebuild_final_missing_source_video_writes_error_artifact(monkeypatch, tmp_path):
    import backend.tasks as tasks

    task_id = "77777777-7777-7777-7777-777777777778"
    upload_dir = tmp_path / "uploads"
    upload_dir.mkdir()
    (upload_dir / f"{task_id}_English.srt").write_text("hello", encoding="utf-8")

    monkeypatch.setenv("UPLOAD_DIR", str(upload_dir))
    monkeypatch.setattr(tasks.rebuild_final_video_task, "update_state", lambda *args, **kwargs: None)

    with pytest.raises(FileNotFoundError, match="Source video not found"):
        tasks.rebuild_final_video_task.run(task_id, "English", "srt")

    artifact = (upload_dir / f"{task_id}_error.json").read_text(encoding="utf-8")
    assert "source_video_missing" in artifact


def test_rebuild_final_missing_subtitle_writes_error_artifact(monkeypatch, tmp_path):
    import backend.tasks as tasks

    task_id = "77777777-7777-7777-7777-777777777779"
    upload_dir = tmp_path / "uploads"
    upload_dir.mkdir()
    (upload_dir / f"{task_id}.mp4").write_bytes(b"video")

    monkeypatch.setenv("UPLOAD_DIR", str(upload_dir))
    monkeypatch.setattr(tasks.rebuild_final_video_task, "update_state", lambda *args, **kwargs: None)

    with pytest.raises(FileNotFoundError, match="Subtitle file not found"):
        tasks.rebuild_final_video_task.run(task_id, "English", "srt")

    artifact = (upload_dir / f"{task_id}_error.json").read_text(encoding="utf-8")
    assert "subtitle_file_missing" in artifact


def test_rebuild_final_ffmpeg_burn_failure_writes_error_artifact(monkeypatch, tmp_path):
    import backend.tasks as tasks
    import backend.utils.subtitle_video_utils as subtitle_video_utils

    task_id = "77777777-7777-7777-7777-777777777780"
    upload_dir = tmp_path / "uploads"
    upload_dir.mkdir()
    (upload_dir / f"{task_id}.mp4").write_bytes(b"video")
    (upload_dir / f"{task_id}_English.srt").write_text("hello", encoding="utf-8")

    def fail_burn(*_args, **_kwargs):
        raise RuntimeError("ffmpeg burn failed")

    monkeypatch.setenv("UPLOAD_DIR", str(upload_dir))
    monkeypatch.setattr(subtitle_video_utils, "burn_subtitles", fail_burn)
    monkeypatch.setattr(tasks.rebuild_final_video_task, "update_state", lambda *args, **kwargs: None)

    with pytest.raises(RuntimeError, match="ffmpeg burn failed"):
        tasks.rebuild_final_video_task.run(task_id, "English", "srt")

    artifact = (upload_dir / f"{task_id}_error.json").read_text(encoding="utf-8")
    assert "ffmpeg_not_found" in artifact


def test_rebuild_final_required_storage_upload_failure_fails_task(monkeypatch, tmp_path):
    import backend.tasks as tasks
    import backend.utils.subtitle_video_utils as subtitle_video_utils

    task_id = "88888888-8888-8888-8888-888888888888"
    upload_dir = tmp_path / "uploads"
    upload_dir.mkdir()
    (upload_dir / f"{task_id}.mp4").write_bytes(b"video")
    (upload_dir / f"{task_id}_English.srt").write_text("1\n00:00:00,000 --> 00:00:01,000\nhello\n", encoding="utf-8")

    class FailingStorage:
        def upload_file(self, *_args, **_kwargs):
            return False

    def fake_burn(_video_path, _subtitle_path, output_path):
        Path(output_path).write_bytes(b"rebuilt")

    monkeypatch.setenv("UPLOAD_DIR", str(upload_dir))
    monkeypatch.setattr(tasks.settings, "STORAGE_BACKEND", "s3")
    monkeypatch.setattr(tasks.settings, "S3_UPLOAD_REQUIRED", True)
    monkeypatch.setattr(tasks, "get_storage_backend", lambda: FailingStorage())
    monkeypatch.setattr(subtitle_video_utils, "burn_subtitles", fake_burn)
    monkeypatch.setattr(tasks.rebuild_final_video_task, "update_state", lambda *args, **kwargs: None)

    with pytest.raises(RuntimeError, match=f"Object storage upload failed for {task_id}_final.mp4"):
        tasks.rebuild_final_video_task.run(task_id, "English", "srt")

    artifact = (upload_dir / f"{task_id}_error.json").read_text(encoding="utf-8")
    assert "final_video_upload_failed" in artifact
