from __future__ import annotations

import argparse
import fnmatch
import os
import sys
import zipfile
from pathlib import Path


EXCLUDED_DIR_NAMES = frozenset({
    ".git",
    ".github",
    ".vscode",
    ".tmp",
    "__pycache__",
    "node_modules",
    "dist",
    "build",
    ".vite",
    ".npm-cache",
    ".cache",
    "uploads",
    "outputs",
    "temp",
    "tmp",
    "data_tmp",
    "segments",
    "release_out",
    "release_pkg",
    ".release_staging",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    "htmlcov",
    ".venv",
    "venv",
    "env",
})

EXCLUDED_RELATIVE_PATHS = frozenset({
    "backend/uploads",
    "backend/outputs",
    "backend/tmp",
    "frontend/node_modules",
    "frontend/dist",
    "scripts/dev_bootstrap.py",
    "scripts/dev_start.py",
    "scripts/start-dev.cmd",
    "scripts/start-dev.ps1",
    "scripts/stop-dev.cmd",
    "scripts/stop-dev.ps1",
})

EXCLUDED_GLOBS = frozenset({
    "*.pyc",
    "*.pyo",
    "*.pyd",
    "*.zip",
    "*.tar.gz",
    "*.tar.bz2",
    "*.log",
    "*.tmp",
    "*.key",
    "*.pem",
    "secrets.*",
})

SENSITIVE_ENV_PATHS = frozenset({
    ".env",
    ".env.local",
    "backend/.env",
    "frontend/.env",
})
ZIP_TIMESTAMP = (2024, 1, 1, 0, 0, 0)
FILE_MODE = 0o644
EXECUTABLE_MODE = 0o755


def _is_env_file(rel_posix: str) -> bool:
    if rel_posix in SENSITIVE_ENV_PATHS:
        return True
    path = Path(rel_posix)
    if path.name == ".env.example":
        return False
    return path.name == ".env" or path.name == ".env.local" or path.name.startswith(".env.")


def _is_excluded(rel_posix: str) -> bool:
    parts = rel_posix.split("/")
    for idx in range(len(parts)):
        sub_path = "/".join(parts[: idx + 1])
        if sub_path in EXCLUDED_RELATIVE_PATHS:
            return True
        if parts[idx] in EXCLUDED_DIR_NAMES:
            return True

    filename = parts[-1]
    return any(fnmatch.fnmatch(filename, pattern) for pattern in EXCLUDED_GLOBS)


def build_release_zip(repo_root: Path, out_path: Path) -> None:
    repo_root = repo_root.resolve()
    out_path = out_path.resolve()

    out_path.parent.mkdir(parents=True, exist_ok=True)

    if out_path.exists():
        out_path.unlink()

    try:
        out_rel_posix = out_path.relative_to(repo_root).as_posix()
    except ValueError:
        out_rel_posix = None

    entries: list[tuple[Path, str]] = []
    for dirpath, dirnames, filenames in os.walk(repo_root):
        # Prune excluded directories in-place to prevent descending into them
        dirnames[:] = sorted(d for d in dirnames if d not in EXCLUDED_DIR_NAMES)
        for filename in sorted(filenames):
            abs_path = Path(dirpath) / filename
            rel_path = abs_path.relative_to(repo_root)
            rel_posix = rel_path.as_posix()

            # Skip the output zip file itself
            if out_rel_posix is not None and rel_posix == out_rel_posix:
                continue

            parts = rel_posix.split("/")
            if parts[0] in EXCLUDED_DIR_NAMES:
                continue
            if _is_env_file(rel_posix):
                continue
            if _is_excluded(rel_posix):
                continue
            entries.append((abs_path, rel_posix))

    with zipfile.ZipFile(out_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for abs_path, rel_posix in sorted(entries, key=lambda item: item[1]):
            info = zipfile.ZipInfo(rel_posix, date_time=ZIP_TIMESTAMP)
            mode = EXECUTABLE_MODE if os.access(abs_path, os.X_OK) else FILE_MODE
            info.external_attr = (mode & 0xFFFF) << 16
            with open(abs_path, "rb") as f:
                zf.writestr(info, f.read(), compress_type=zipfile.ZIP_DEFLATED)


def _assert_release_zip_clean(out_path: Path) -> None:
    with zipfile.ZipFile(out_path, "r") as archive:
        names = archive.namelist()

    forbidden_dir_names = {"tmp", "temp", "data_tmp", "uploads", "outputs"}

    required = {
        "VERSION",
        "CHANGELOG.md",
        "README.md",
        "DEPLOYMENT.md",
        "SECURITY.md",
        "docker-compose.yml",
        "backend/.env.example",
        "frontend/.env.example",
        "backend/Dockerfile",
        "frontend/Dockerfile",
        "frontend/package.json",
        "requirements.txt",
        "tests/test_api_contracts.py",
    }

    for name in names:
        normalized = name.lstrip("./")
        # Check if any forbidden directory is in the path
        parts = normalized.split("/")
        if parts[0] in forbidden_dir_names:
            raise SystemExit(f"release zip contains forbidden content: {normalized}")
        if _is_env_file(normalized) or _is_excluded(normalized):
            raise SystemExit(f"release zip contains forbidden content: {normalized}")

    missing = sorted(required - set(names))
    if missing:
        raise SystemExit(f"release zip is missing required files: {', '.join(missing)}")


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description="Build a clean, reproducible release zip for ai_subtitle_tool.")
    parser.add_argument("--repo-root", default=str(Path(__file__).resolve().parents[1]), help="Repository root path")
    parser.add_argument("--out", default="release.zip", help="Output zip path (relative to repo root unless absolute)")
    parser.add_argument("--check", action="store_true", help="Fail if the produced zip contains forbidden paths/files")
    args = parser.parse_args(argv)

    repo_root = Path(args.repo_root).resolve()
    out_path = (repo_root / args.out).resolve()

    build_release_zip(repo_root, out_path)
    if args.check:
        _assert_release_zip_clean(out_path)

    print(str(out_path))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
