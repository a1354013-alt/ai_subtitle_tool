export type APIError = {
  message: string;
  status?: number;
  detail?: unknown;
  error_code?: string;
  suggestion?: string;
};

export type ErrorResponse = {
  success: false;
  error_code: string;
  message: string;
  suggestion: string;
};

export type AppConfig = {
  version: string;
  maxUploadSizeMb: number;
  maxBatchFiles: number;
  supportedExtensions: string[];
  batchUploadEnabled: boolean;
  subtitleFormats: string[];

  translationEnabled: boolean;
  openaiConfigured: boolean;
  defaultTargetLanguage: string;
  availableModes: string[];
  provider: string;
  model?: string | null;
  reason?: string | null;
  message?: string | null;
};

export type AppCapabilities = {
  provider: string;
  model?: string | null;
  translationEnabled: boolean;
  reason?: string | null;
  message?: string | null;
  defaultTargetLanguage: string;
  availableModes: string[];
  openaiConfigured: boolean;
};

export type BatchTaskStatus = "PENDING" | "PROCESSING" | "SUCCESS" | "FAILURE" | "CANCELED";

export type BatchSubtitleDownloadUrls = {
  srt?: string;
  ass?: string;
  vtt?: string;
};

export type BatchDownloadUrls = {
  video?: string;
  subtitles: Record<string, BatchSubtitleDownloadUrls>;
};

export type BatchTaskResponse = {
  task_id: string;
  filename: string;
  status: BatchTaskStatus | string;
  progress: number;
  message?: string | null;
  error?: string | null;
  download_urls?: BatchDownloadUrls | null;
};

export type BatchUploadResponse = {
  batch_id: string;
  tasks: BatchTaskResponse[];
};

export type BatchStatusResponse = {
  batch_id: string;
  total: number;
  completed: number;
  failed: number;
  processing: number;
  pending: number;
  tasks: BatchTaskResponse[];
};
