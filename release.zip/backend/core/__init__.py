"""Core backend helpers."""

