"""Core backend helpers."""

