import logging
import os

from .subtitle_text_utils import generate_srt

logger = logging.getLogger(__name__)


def transcribe_video(video_path: str, output_srt_path: str, model_size=None):
    """
    Transcribe a video file into an SRT subtitle file.

    Returns a list of segments with (start, end, text) attributes.
    """
    audio_path = None
    try:
        # 1) Read duration for model selection
        from moviepy.editor import VideoFileClip

        from .audio_utils import preprocess_audio
        from .model_loader import get_model, resolve_model_size

        video = VideoFileClip(video_path)
        duration = video.duration
        video.close()

        model_size = resolve_model_size(duration, model_size)

        # 2) Extract audio to a temporary wav
        audio_path = f"{os.path.splitext(video_path)[0]}_temp.wav"
        preprocess_audio(video_path, audio_path)

        # 3) Run Faster-Whisper
        model = get_model(model_size)
        segments, _info = model.transcribe(audio_path, beam_size=5)
        segments_list = list(segments)

        # 4) Write SRT
        srt_content = generate_srt(segments_list)
        with open(output_srt_path, "w", encoding="utf-8", newline="\n") as f:
            f.write(srt_content)

        return segments_list
    finally:
        if audio_path and os.path.exists(audio_path):
            try:
                os.remove(audio_path)
            except OSError:
                logger.warning("Failed to remove temp audio: %s", audio_path, exc_info=True)
