from __future__ import annotations

import os
import re
from pathlib import Path
from typing import BinaryIO

from fastapi import HTTPException

from backend import settings

SUPPORTED_VIDEO_EXTENSIONS = set(settings.SUPPORTED_VIDEO_EXTENSIONS)
SUPPORTED_SUBTITLE_FORMATS = set(settings.EDITABLE_SUBTITLE_FORMATS)
SAFE_LANG_SUFFIX_RE = re.compile(r"^[A-Za-z0-9_-]+$")


def sanitize_filename(filename: str | None) -> str:
    raw_name = Path(filename or "upload.bin").name.strip()
    if not raw_name:
        return "upload.bin"
    return re.sub(r"[\x00-\x1f]+", "_", raw_name)


def normalize_target_langs(raw: str) -> list[str]:
    parts = [re.sub(r"\s+", " ", p).strip() for p in (raw or "").split(",")]
    parts = [p for p in parts if p]

    seen: set[str] = set()
    normalized: list[str] = []
    for part in parts:
        key = part.lower()
        if key in seen:
            continue
        seen.add(key)
        normalized.append(part)
    return normalized


def normalize_lang_suffix(lang: str) -> str:
    normalized = re.sub(r"\s+", "_", (lang or "").strip())
    if not normalized:
        raise HTTPException(status_code=400, detail="Language value must not be empty")
    if any(token in normalized for token in ("/", "\\", "..")):
        raise HTTPException(status_code=400, detail=f"Invalid language value: '{lang}'")
    if any(ord(char) < 32 for char in normalized):
        raise HTTPException(status_code=400, detail=f"Invalid language value: '{lang}'")
    if not SAFE_LANG_SUFFIX_RE.fullmatch(normalized):
        raise HTTPException(
            status_code=400,
            detail=f"Invalid language value: '{lang}'. Only alphanumeric, underscore, and hyphen allowed.",
        )
    return normalized


def validate_target_langs(raw: str) -> list[str]:
    langs = normalize_target_langs(raw)
    if not langs:
        raise HTTPException(status_code=400, detail="target_langs must contain at least one non-empty language")
    for lang in langs:
        normalize_lang_suffix(lang)
    return langs


def validate_subtitle_format(subtitle_format: str) -> str:
    normalized = (subtitle_format or "").strip().lower()
    if normalized not in SUPPORTED_SUBTITLE_FORMATS:
        raise HTTPException(status_code=400, detail="subtitle_format must be 'ass' or 'srt'")
    return normalized


def validate_upload_metadata(filename: str | None, content_type: str | None) -> str:
    safe_name = sanitize_filename(filename)
    extension = Path(safe_name).suffix.lower()
    if extension not in SUPPORTED_VIDEO_EXTENSIONS:
        supported = ", ".join(ext.lstrip(".") for ext in sorted(SUPPORTED_VIDEO_EXTENSIONS))
        raise HTTPException(status_code=400, detail=f"Unsupported file format. Supported: {supported}")

    normalized_content_type = (content_type or "").lower()
    if normalized_content_type and not normalized_content_type.startswith("video/") and normalized_content_type != "application/octet-stream":
        raise HTTPException(status_code=400, detail=f"Invalid content type: {content_type}. Expected video/*")
    return safe_name


def validate_upload_size(file_obj: BinaryIO, max_upload_size_mb: int) -> int:
    file_obj.seek(0, os.SEEK_END)
    file_size = file_obj.tell()
    file_obj.seek(0)

    max_bytes = max_upload_size_mb * 1024 * 1024
    if file_size > max_bytes:
        raise HTTPException(status_code=413, detail=f"File too large. Maximum size: {max_upload_size_mb}MB")
    return file_size


def validate_batch_files(files: list, max_batch_files: int) -> None:
    if not files:
        raise HTTPException(status_code=400, detail="No files uploaded")
    if len(files) > max_batch_files:
        raise HTTPException(status_code=400, detail=f"Too many files. Maximum allowed: {max_batch_files}")
